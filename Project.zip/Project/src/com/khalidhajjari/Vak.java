package com.khalidhajjari;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;

public class Vak extends JComponent{

//    private double x;
//    private double y;
//
//    private int xmin;
//    private int ymin;
//    private int xmax;
//    private int ymax;
//
//    private double tween;
//
//    private int [][] map;
//    private int vakSize;
//    private int rij;
//    private int kolom;
//    private int WIDTH;
//    private int HEIGHT;
//
//    private BufferedImage tileset;
//    private int rowOffset;
//    private int colOffset;
//    private int numRowsToDraw;
//    private int numColsToDraw;
//
//    public Vak(int vakSize) {
//        this.vakSize = vakSize;
//        numColsToDraw = 10;
//        numRowsToDraw = 10;
//        tween = 0.07;
//
//    }
//
//    public void loadVakjes(String s){
//        try{
//            tileset = ImageIO.read(getClass().getResourceAsStream(s));
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//
//        map = new map[10][10];
//
//        BufferedImage subimage;
//        for(int kol = 0; kol < 11; kol++){
//            subimage = tileset.getSubimage(kol * vakSize,0,vakSize, vakSize);
//
//            map[0][kol] = new
//        }
//
//
//
//    }
//
//    public void loadMap(String s){
//
//    }

}






