package com.khalidhajjari;

import javax.swing.*;
import java.awt.*;

public class Main {

    public static void main(String[] args) {

//        JFrame frame = new JFrame();
//        frame.setSize(1020, 1100);
//        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
//        frame.setTitle("2Dspel");
//        frame.setVisible(true);

//        Karakter frame = new Karakter();
//        frame.setResizable(true);
//        frame.setTitle("2D spel van Khalid");
//        frame.setSize(1000, 1000);
//        frame.setMinimumSize(new Dimension(1000, 1100));
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        frame.getContentPane().add(frame.karakter);
//        frame.pack();
//        frame.setVisible(true);
//
//
//
//        JComponent component = new createVak();
//        frame.add(component);
//        frame.setVisible(true);



//        JComponent karakter = new KarakterComponent();
//        frame.add(karakter);
//        frame.setVisible(true);
//
//        JComponent knoppen = new Buttons();
//        frame.add(knoppen);
//        frame.setVisible(true);







    }
}
