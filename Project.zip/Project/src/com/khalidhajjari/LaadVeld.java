package com.khalidhajjari;

import java.awt.*;

public class LaadVeld {
//
//    private int kol = 10;
//    private int rij = 10;
//
//    int array[][] = new int[kol][rij];
//
//
//    int breedte;
//    LeegVak vak;
//    SleutelVak test;
//    breekbareBarricade b;
//    KarakterComponent k;
//
//
//    public int[][] laadVeld() {
//        return array;
//    }
//
//    public void setVeld(int s) {
//
//        breedte = vak.MAXX / vak.WIDTH;
//
//        for (int i = 0; i < kol; i++) {
//            for (int j = 0; j < rij [i]; j++) {
//                array[i][j] = 1;
//
//                }
//            }
//        }
//    }
}

